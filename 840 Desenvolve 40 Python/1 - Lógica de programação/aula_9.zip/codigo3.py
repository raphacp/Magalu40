print(bool(0))
print(bool(5))
print(bool(-10))
